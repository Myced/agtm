<?php

class Level
{
    const ADMIN = '10';
    const USER  = '1';
    const MODERATOR = '5';
}
