<?php

class AccountStatus
{
    //declare constants for different account status;
    const BLOCKED = '-1';
    const ACTIVE = '1';
    const SUSPENDED = '0';
}
 ?>
