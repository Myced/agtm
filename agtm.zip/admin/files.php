<?php
    //process file here
    
 ?>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
     <head>
         <meta charset="utf-8">
         <title>files</title>
     </head>
     <body>
         <form class="" action="" method="post" enctype="multipart/form-data">
             <input type="file" name="file" value="">
             <input type="submit" name="" value="upload">
         </form>
     </body>
 </html>
