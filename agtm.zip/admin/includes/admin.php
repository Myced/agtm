<?php

//script to determine if the currently logged in user has access to this page or not


 ?>
