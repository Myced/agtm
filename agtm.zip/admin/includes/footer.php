                    </div> <!-- container -->

                </div> <!-- content -->
            

                <footer class="footer text-right">
                    <?php echo date("Y"); ?> © AGTM. - Powered By PEFSCOM
                </footer>

            </div>


            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->
