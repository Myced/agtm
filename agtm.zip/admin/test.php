<?php
include_once '../classes/class.dbc.php';
include_once 'classes/class.Product.php';
include_once '../includes/functions.php';


$date = agtm_date('2019-12-12 12:12:12');

echo file_exists('includes/');
$product = new Product('PR-000010');


 ?>
