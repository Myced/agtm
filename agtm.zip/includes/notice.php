<div class="notice">
    <div class="notice-head">
        <i class="fa fa-warning fa-2x"></i> Notice
    </div>
    <div class="notice-body">
        <div class="text-center">
            You are Required to log in to view this page.
            <br>

            <a href="login.php" title="Log In">Click here</a> to log in
        </div>
    </div>
</div>
<br><br><br><br><br><Br>
