<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>AGTM</title>

        <link rel="shortcut icon" href="admin/assets/images/favicon.ico">

        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/AdminLTE.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/toastr.css">
